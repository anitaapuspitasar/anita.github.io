// Clear form before unload
window.onbeforeunloud = () => {
    for (const form of document.getElementsByTagName("form")) {
        form.reset();
    }
}